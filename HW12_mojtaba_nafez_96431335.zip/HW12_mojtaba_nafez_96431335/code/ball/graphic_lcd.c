#include <mega32.h>
#include <delay.h>
#include <glcd.h>
#include <font5x7.h>
                 
// 
void main(void)
{
int x=63,y=31;
int i=1,j=1;
GLCDINIT_t glcd_init_data;
glcd_init_data.font=font5x7;
glcd_init(&glcd_init_data);
glcd_clear();
delay_ms(50);
glcd_outtext("mojtaba nafez \n nafez");
delay_ms(i);
glcd_clear();
while (1)
      {
      glcd_setlinestyle(1,GLCD_LINE_SOLID);
      glcd_circle(x,y,5);      
      delay_ms(20); 
       if(x==3)
        i*=(-1);
      if(y==2)
        j*=(-1);
      if(x==122)
        i*=(-1);
      if(y==59)
        j*=(-1);
      x+=i;
      y+=j;
      glcd_clear();
      
      }

}