#include <mega32.h>
#include <delay.h>
#include <glcd.h>
#include <font5x7.h>
                 
// 
void main(void)
{
int i=500;
GLCDINIT_t glcd_init_data;
glcd_init_data.font=font5x7;
glcd_init(&glcd_init_data);
glcd_clear();
delay_ms(50);
glcd_outtext("    mojtaba nafez \n\n       nafez");
delay_ms(i);
glcd_clear();

       
glcd_setlinestyle(2,GLCD_LINE_SOLID);
glcd_line(42,61,82,61);
glcd_line(42,61,42, 35);
glcd_line(82,35,82,61);
glcd_line(82,35,92, 35);
glcd_line(62,1,92, 35);

glcd_line(32,35,42, 35);

glcd_line(32,35,42, 25);
glcd_line(42,7,42, 25);

glcd_line(49, 18,62, 1);
glcd_line(49, 18,49,7 );
glcd_line(49, 7, 52, 7);
glcd_line(42,7, 39, 7);
glcd_line(39, 7, 39, 2);
glcd_line(52,7,52,2);
glcd_line(52, 2, 39, 2);


while (1)
      {
      }

}