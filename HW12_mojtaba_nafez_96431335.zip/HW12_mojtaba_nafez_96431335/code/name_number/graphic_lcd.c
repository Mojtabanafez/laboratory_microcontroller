#include <mega32.h>
#include <delay.h>
#include <glcd.h>
#include <font5x7.h>
                 
// 
void main(void)
{
int i=500;
GLCDINIT_t glcd_init_data;
glcd_init_data.font=font5x7;
glcd_init(&glcd_init_data);
glcd_clear();
delay_ms(50);
glcd_outtext("\n\n    mojtaba nafez \n\n      96431335");
while (1)
      {
      }

}