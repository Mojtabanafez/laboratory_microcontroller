#include <mega32.h>
#include <i2c.h>
#include <ds1307.h>
#include <alcd.h>  
#include <stdio.h>
#include <stdlib.h>
#include <delay.h>

unsigned char hour,minute,sec;
unsigned char week_day, day, month, year;
char * str;

void main(void)
{

PORTA=0x00;
DDRA=0x00;

PORTB=0x00;
DDRB=0x00;

PORTC=0x00;
DDRC=0x00;

PORTD=0x00;
DDRD=0x00;

TCCR0=0x00;
TCNT0=0x00;
OCR0=0x00;

TCCR1A=0x00;
TCCR1B=0x00;
TCNT1H=0x00;
TCNT1L=0x00;
ICR1H=0x00;
ICR1L=0x00;
OCR1AH=0x00;
OCR1AL=0x00;
OCR1BH=0x00;
OCR1BL=0x00;

ASSR=0x00;
TCCR2=0x00;
TCNT2=0x00;
OCR2=0x00;

MCUCR=0x00;
MCUCSR=0x00;

TIMSK=0x00;

UCSRB=0x00;

ACSR=0x80;
SFIOR=0x00;

ADCSRA=0x00;

SPCR=0x00;

TWCR=0x00;

i2c_init();

rtc_init(0,0,0);

lcd_init(20);
//rtc_set_date(20, 21, 5, 19);
while (1)
      {
           rtc_get_time(&hour, &minute, &sec);    
           lcd_clear();
           lcd_gotoxy(0, 0);    
           lcd_putsf("TIME> ");
           itoa(hour, str);
           lcd_puts(str);
           lcd_putsf(" ");           
           itoa(minute, str);
           lcd_puts(str);           
           lcd_putsf(" ");           
           itoa(sec, str);
           lcd_puts(str);
           lcd_putsf(" ");
                   
           rtc_get_date(&week_day, &day, &month, &year);     
           lcd_gotoxy(0, 1);
           lcd_putsf("DATE> ");
           itoa(day, str);
           lcd_puts(str);
           lcd_putsf(" ");
           itoa(month, str);
           lcd_puts(str);
           lcd_putsf(" 20"); 
           itoa(year, str);
           lcd_puts(str);
           lcd_putsf(" "); 
           delay_ms(1000);
      }
}
