#include <mega32.h>
#include <delay.h>
#include <alcd.h>
#include <stdlib.h>

//#define ADC_VREF_TYPE 0x40
#define ADC_VREF_TYPE ( (1<< REFS1) | (1<<REFS0) | (0<<ADLAR) )

unsigned int read_adc(unsigned char adc_input)
{
//ADMUX=adc_input | (ADC_VREF_TYPE & 0xff);
ADMUX=adc_input | ADC_VREF_TYPE;

delay_us(10);
//ADCSRA|=0x40;
ADCSRA|=(1<<ADSC);

//while ((ADCSRA & 0x10)==0);
while( (ADCSRA & ( 1<<ADIF ))==0 );
ADCSRA|=(1<<ADIF);
//ADCSRA|=0x10;
return ADCW;
}


void main(void)
{
char *a="";
char degree =161;
int tmp=0;
DDRA=0x00;

PORTB=0x00;
DDRB=0x00;

PORTC=0x00;
DDRC=0x00;

PORTD=0x00;
DDRD=0x00;

TCCR0=0x00;
TCNT0=0x00;
OCR0=0x00;

TCCR1A=0x00;
TCCR1B=0x00;
TCNT1H=0x00;
TCNT1L=0x00;
ICR1H=0x00;
ICR1L=0x00;
OCR1AH=0x00;
OCR1AL=0x00;
OCR1BH=0x00;
OCR1BL=0x00;

ASSR=0x00;
TCCR2=0x00;
TCNT2=0x00;
OCR2=0x00;

MCUCR=0x00;
MCUCSR=0x00;

TIMSK=0x00;

UCSRB=0x00;

ACSR=0x80;
SFIOR=0x00;

ADMUX=ADC_VREF_TYPE & 0xff;
ADCSRA=0x85;

SPCR=0x00;

TWCR=0x00;

lcd_init(16);

lcd_clear();

lcd_gotoxy(2,0);
lcd_puts("LM35 SENSOR");
lcd_gotoxy(2,1);
lcd_puts("TEMP:    �C");
lcd_gotoxy(11,1);
lcd_putchar(degree);
while (1)
      {
        tmp =read_adc(DDRA); 
      //  tmp*=4.88;
      //  tmp/=10;
        tmp/=4;
        itoa(tmp,a );
        if(tmp<10){
            lcd_gotoxy(8,1);
            lcd_puts(a);
            lcd_gotoxy(9,1);
            lcd_puts("  ");
        }else if(tmp<100){
            lcd_gotoxy(8,1);
            lcd_puts(a);
            lcd_gotoxy(10,1);
            lcd_puts(" ");
        }else{
            lcd_gotoxy(8,1);
            lcd_puts(a);
        }
               
      }
}