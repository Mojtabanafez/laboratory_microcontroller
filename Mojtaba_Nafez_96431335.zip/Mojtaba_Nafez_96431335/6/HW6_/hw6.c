#include <mega32.h>
#include <delay.h>
#include <stdlib.h>
#include <alcd.h>
int hour = 23;
int minute = 58;
int second = 0;
int dahom = 0;
          

interrupt [TIM1_COMPA] void timer1_compa_isr(void)
{
    dahom++;
    if(dahom>9){
        dahom=0;
        second++;
        if(second>=60){
            second =0;
            minute++;
            if(minute>=60){
                minute =0;
                hour++;
                if(hour>=24){
                    hour =0;
                }
            }
        } 
    }
    
}

void main(void)
{
char *a="";

PORTA=0x00;
DDRA=0x00;

PORTB=0x00;
DDRB=0x00;

PORTC=0x00;
DDRC=0x00;

PORTD=0x00;
DDRD=0x00;

TCCR0=0x00;
TCNT0=0x00;
OCR0=0x00;

TCCR1A=0x00;
TCCR1B=0x0C;
TCNT1H=0x00;
TCNT1L=0x00;
ICR1H=0x00;
ICR1L=0x00;
OCR1AH=0x0c;
OCR1AL=0x35;
OCR1BH=0x00;
OCR1BL=0x00;

ASSR=0x00;
TCCR2=0x00;
TCNT2=0x00;
OCR2=0x00;

MCUCR=0x00;
MCUCSR=0x00;

TIMSK=0x10;

UCSRB=0x00;

ACSR=0x80;
SFIOR=0x00;

ADCSRA=0x00;

SPCR=0x00;

TWCR=0x00;

lcd_init(16);

#asm("sei") 

lcd_clear();
lcd_gotoxy(5,0);
lcd_putchar('I');
lcd_gotoxy(7,0);
lcd_putchar('U');
lcd_gotoxy(9,0);
lcd_putchar('S');
lcd_gotoxy(11,0);
lcd_putchar('T');

lcd_gotoxy(5,1);
lcd_putchar(':');

lcd_gotoxy(8,1);
lcd_putchar(':');

lcd_gotoxy(11,1);
lcd_putchar(':');
while (1)
      {
        if(hour==0){
            lcd_gotoxy(3,1);      
            lcd_puts("0 ");
        }
        else{   
            itoa(hour,a );
            lcd_gotoxy(3,1);      
            lcd_puts(a);
        }       
        
        
        if(minute==0){
            lcd_gotoxy(6,1);      
            lcd_puts("0 ");
        }else{
            itoa(minute,a );
            lcd_gotoxy(6,1);      
            lcd_puts(a);    
        }
        
        
        if(second==0){
            lcd_gotoxy(9,1) ;
            lcd_puts("0 ");
        }
        else{
            itoa(second,a );
            lcd_gotoxy(9,1);      
            lcd_puts(a);        
        }
        
        
        itoa(dahom,a );
        lcd_gotoxy(12,1);      
        lcd_puts(a);
                
      }
}
