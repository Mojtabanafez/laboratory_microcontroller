#include <mega32.h>
#include <delay.h>

const unsigned char pointer[48] ={
   
    0xFF,	//	0001		# # # # # # # # 
	0xFF,	//	0002		# # # # # # # # 
	0xFF,	//	0003		# # # # # # # # 
	0x83,	//	0004		# . . . . . # # 
	0xED,	//	0005		# # # . # # . # 
	0xEE,	//	0006		# # # . # # # . 
	0xED,	//	0007		# # # . # # . # 
	0x83 ,	//	0008		# . . . . . # #
    
    0xFF,	//	0001		# # # # # # # # 
    0xFF,    //    0002        # # # # # # # # 
    0xFF,    //    0003        # # # # # # # # 
    0x80,    //    0004        # . . . . . . . 
    0xB6,    //    0005        # . # # . # # . 
    0xB6,    //    0006        # . # # . # # . 
    0xB6,    //    0007        # . # # . # # . 
    0xC1 ,    //    0008        # # . . . . . # 

    0xFF,    //    0001        # # # # # # # # 
    0xFF,    //    0002        # # # # # # # # 
    0xFF,    //    0003        # # # # # # # # 
    0xC1,    //    0004        # # . . . . . # 
    0xBE,    //    0005        # . # # # # # . 
    0xBE,    //    0006        # . # # # # # . 
    0xBE,    //    0007        # . # # # # # . 
    0xDD ,    //    0008        # # . # # # . # 
   
    0xFF,    //    0001        # # # # # # # # 
    0xFF,    //    0002        # # # # # # # # 
    0xFF,    //    0003        # # # # # # # # 
    0x80,    //    0004        # . . . . . . . 
    0xBE,    //    0005        # . # # # # # . 
    0xBE,    //    0006        # . # # # # # . 
    0xBE,    //    0007        # . # # # # # . 
    0xC1 ,    //    0008        # # . . . . . # }

    0xFF,    //    0001        # # # # # # # # 
    0xFF,    //    0002        # # # # # # # # 
    0xFF,    //    0003        # # # # # # # # 
    0x80,    //    0004        # . . . . . . . 
    0xB6,    //    0005        # . # # . # # . 
    0xB6,    //    0006        # . # # . # # . 
    0xB6,    //    0007        # . # # . # # . 
    0xBE ,    //    0008        # . # # # # # . 

    0xFF,    //    0001        # # # # # # # # 
    0xFF,    //    0002        # # # # # # # # 
    0xFF,    //    0003        # # # # # # # # 
    0x80,    //    0004        # . . . . . . . 
    0xF6,    //    0005        # # # # . # # . 
    0xF6,    //    0006        # # # # . # # . 
    0xF6,    //    0007        # # # # . # # . 
    0xFE ,    //    0008        # # # # # # # . 
};
void main(void)
{
unsigned char tmp[16];
unsigned char Col, Scan,k, j, f, c, g;
DDRC = 0xFF;
DDRB = 0xFF;
DDRD = 0xFF;

while (1)
      {
                for(j=16; j<64; j++){
                    if(j<48 ){
                        k = j-16;
                        Scan = 0b00000001;
                        for(Col=k; Col<k+8; Col++){
                            PORTD = Scan;
                            Scan = Scan << 1;  
                            PORTC = pointer[Col];
                            delay_ms(4);
                        }   
                        PORTD=0;     
                        Scan = 0b00000001;
                        for(Col=k+8; Col<k+16; Col++){
                            PORTB = Scan;
                            Scan = Scan << 1;  
                            PORTC = pointer[Col];
                            delay_ms(4);
                        }
                    }else{           
                        c=0;
                        for(f=(j-15); f<=47; f++){
                             tmp[c]= pointer[f];
                             c++;
                        }   
                        g=0;
                        for(; c<16 ; c++){
                            tmp[c] = pointer[g];
                            g++;
                        }
                      
                        
                        Scan = 0b00000001;
                        for(Col=0; Col<8; Col++){
                            PORTD = Scan;
                            Scan = Scan << 1;  
                            PORTC = tmp[Col];
                            delay_ms(4);
                        }      
                        
                        PORTD = 0;
                        Scan = 0b00000001;
                        for(Col=8; Col<16; Col++){
                            PORTB = Scan;
                            Scan = Scan << 1;  
                            PORTC = tmp[Col];
                            delay_ms(4);
                        }
                          
                     }
                }           
      }
}