#include <mega32.h>
#include <delay.h>
int hour = 23;
int minute = 58;
int second = 58;

void delay(){
    TCNT0 =0X00;
    OCR0 = 63;
    TCCR0 = 0X0C;  
    while((TIFR & (1<<TOV0))==0);
    TCCR0 = 0;
    TIFR = 0X1;
}

interrupt [TIM1_COMPA] void timer1_compa_isr(void)
{
    second++;
    if(second>=60){
        second = 0;
        minute++;
        if(minute>=60){
            minute =0;
            hour++;
            if(hour>=24){
                hour =0;
            }
        }
    }
}


void main(void)
{
unsigned  char array[] = {0X3F,0X06, 0X5B, 0X4F, 0X66, 0X6D, 0X7D, 0X07, 0X7F, 0X6F};
int yekan = 0;
int sadgan=0;
int flag = 0;

PORTB=0x00;
DDRB=0xFF;

PORTC=0x00;
DDRC=0xFF;

PORTD=0x00;
DDRD=0xFF;

TCCR0=0x00;
TCNT0=0x00;
OCR0=0x00;

TCCR1A=0x00;
TCCR1B=0x0C;
TCNT1H=0x00;
TCNT1L=0x00;
ICR1H=0x00;
ICR1L=0x00;
OCR1AH=0x7A;
OCR1AL=0x12;
OCR1BH=0x00;
OCR1BL=0x00;


ASSR=0x00;
TCCR2=0x00;
TCNT2=0x00;
OCR2=0x00;

MCUCR=0x00;
MCUCSR=0x00;

TIMSK=0x10;

ACSR=0x80;
SFIOR=0x00;

#asm("sei")

while (1)
      {     if(second%2==0){
                flag =1;
            }else{
                flag = 0;
            }    
            yekan = second%10;
            sadgan = second /10;

            PORTD = 0b11011111;
            if(flag)
                PORTC = array[yekan]| 0x80;
            else
                PORTC = array[yekan];
            delay();
            PORTD = 0b11101111;
            PORTC = array[sadgan];
            delay();
            //////////////////////////////
            yekan = minute%10;
            sadgan = minute/10;

            PORTD = 0b11110111;
            if(flag)
                PORTC = array[yekan]| 0x80;
            else
                PORTC = array[yekan];
            delay();
            
            PORTD = 0b11111011;
            PORTC = array[sadgan];
            delay();
            ///////////////////////////////
            yekan = hour%10;
            sadgan = hour /10;

            PORTD = 0b1111101;
            if(flag)
                PORTC = array[yekan]| 0x80;
            else
                PORTC = array[yekan];
            delay();
                     
            PORTD = 0b11111110;
            PORTC = array[sadgan];
            delay();         
      };
}