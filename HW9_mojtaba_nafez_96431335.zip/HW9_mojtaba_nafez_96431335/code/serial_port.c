#include <mega32.h>
#include <alcd.h>
#include <stdio.h>
#include <delay.h>

unsigned char a;
unsigned char i=0;
void usart_send_string(char *str);


void main(void)
{
PORTA=0x00;
DDRA=0x00;

PORTB=0x00;
DDRB=0x00;

PORTC=0x00;
DDRC=0x00;

PORTD=0x00;
DDRD=0x00;

TCCR0=0x00;
TCNT0=0x00;
OCR0=0x00;

TCCR1A=0x00;
TCCR1B=0x00;
TCNT1H=0x00;
TCNT1L=0x00;
ICR1H=0x00;
ICR1L=0x00;
OCR1AH=0x00;
OCR1AL=0x00;
OCR1BH=0x00;
OCR1BL=0x00;


ASSR=0x00;
TCCR2=0x00;
TCNT2=0x00;
OCR2=0x00;


MCUCR=0x00;
MCUCSR=0x00;

TIMSK=0x00;

UCSRA=0x00;
UCSRB=0x18;
UCSRC=0x86;
UBRRH=0x00;
UBRRL=0x33;

ACSR=0x80;
SFIOR=0x00;

ADCSRA=0x00;

SPCR=0x00;

TWCR=0x00;

lcd_init(16);
lcd_clear();
lcd_gotoxy(0, 0);

while (1)
    {
        a = getchar();
        putchar(a);
        
        if(a=='C'){
            lcd_clear();
            lcd_gotoxy(0, 0);
        }else if( a == 'N' ){
            usart_send_string("\n\rMojtaba nafez\n\r");
        }else if( a == 'c' ){
                usart_send_string("\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r");
        }else if( a == 'M' ){
                lcd_clear();
                lcd_gotoxy(0, 0);   
                lcd_puts("  mojtaba nafez");
        }
        else{
           lcd_putchar(a); 
        }
    }
}

void usart_send_string(char *str)
{
    for(i=0;str[i];i++)
    putchar(str[i]);
}