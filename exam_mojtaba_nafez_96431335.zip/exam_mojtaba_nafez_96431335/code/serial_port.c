#include <mega32.h>
#include <stdio.h>
#include <delay.h>
#include <stdlib.h>

unsigned char i;
void usart_send_string(char *str);


void main(void)
{

unsigned char str_prev;
unsigned char str_now;
unsigned char value=0;
char* result="";
PORTA=0x00;
DDRA=0x00;

PORTB=0x00;
DDRB=0x00;


DDRC = 0X00;
PORTC = 0XFF;

PORTD=0x00;
DDRD=0x00;

TCCR0=0x00;
TCNT0=0x00;
OCR0=0x00;

TCCR1A=0x00;
TCCR1B=0x00;
TCNT1H=0x00;
TCNT1L=0x00;
ICR1H=0x00;
ICR1L=0x00;
OCR1AH=0x00;
OCR1AL=0x00;
OCR1BH=0x00;
OCR1BL=0x00;


ASSR=0x00;
TCCR2=0x00;
TCNT2=0x00;
OCR2=0x00;


MCUCR=0x00;
MCUCSR=0x00;

TIMSK=0x00;

UCSRA=0x00;
UCSRB=0x18;
UCSRC=0x86;
UBRRH=0x00;
UBRRL=0x33;

ACSR=0x80;
SFIOR=0x00;

ADCSRA=0x00;

SPCR=0x00;

TWCR=0x00;
usart_send_string("In the name of God\n\r");

str_now = PINC;
value=(PINC.0*1)+(PINC.1*2)+(PINC.2*4)+(PINC.3*8)+(PINC.4*16)+(PINC.5*32)+(PINC.6*64)+(PINC.7*128);
itoa(value,result);
usart_send_string(result);
putchar('\n\r');
str_prev =str_now;
while (1)
    {
        str_now = PINC;
        if  (str_now!=str_prev){ 
            value=(PINC.0*1)+(PINC.1*2)+(PINC.2*4)+(PINC.3*8)+(PINC.4*16)+(PINC.5*32)+(PINC.6*64)+(PINC.7*128);
            itoa(value,result);
            usart_send_string(result);
            putchar('\n\r');
            str_prev =str_now;
        
        }
    }
}

void usart_send_string(char *str)
{
    for(i=0;str[i];i++)
    putchar(str[i]);
}