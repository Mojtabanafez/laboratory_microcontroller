#include <mega32.h>
#include <alcd.h>
#include <delay.h>
#include <stdlib.h>


signed char a = 0, b = 1;
interrupt [EXT_INT0] void ext_int0_isr(void)
{
    a+=b   ;
    delay_ms(10);
    
}

interrupt [EXT_INT1] void ext_int1_isr(void)
{
    a-=b;
    delay_ms(10);

}

interrupt [EXT_INT2] void ext_int2_isr(void)
{       DDRC ^= 1 << 3;
        PORTC ^= 1 << 3;
        if(b==1){
            b = 10;
        }else{
            b = 1;
        }
        delay_ms(10);         
}

void main(void)
{
char *str="";

PORTA=0x00;
DDRA=0x00;

PORTB=0x00;
DDRB=0x00;

PORTC=0x00;
DDRC=0x00;

PORTD=0x00;
DDRD=0x00;

TCCR0=0x00;
TCNT0=0x00;
OCR0=0x00;

TCCR1A=0x00;
TCCR1B=0x00;
TCNT1H=0x00;
TCNT1L=0x00;
ICR1H=0x00;
ICR1L=0x00;
OCR1AH=0x00;
OCR1AL=0x00;
OCR1BH=0x00;
OCR1BL=0x00;

ASSR=0x00;
TCCR2=0x00;
TCNT2=0x00;
OCR2=0x00;

GICR|=0xE0;
MCUCR=0x02;
MCUCSR=0x00;
GIFR=0xE0;

TIMSK=0x00;

UCSRB=0x00;

ACSR=0x80;
SFIOR=0x00;

ADCSRA=0x00;

SPCR=0x00;

TWCR=0x00;

lcd_init(16);
lcd_clear();
#asm("sei")

while (1)
      {  
          lcd_gotoxy(0,0);
          itoa(a,str);                                                                                      
          lcd_puts(str);  
          lcd_putchar(' ');
          lcd_putchar(' ');
          delay_ms(50);
      }
}
